#include "GameManagerClass.hpp"

int main()
{
		GameManager::getInstance()->run();
        return 0;

}

/*
That's it. Compile and run.
**/
