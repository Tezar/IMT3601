#include "StdAfx.h"
#include "GameSession.hpp"


GameSession::GameSession(void)
{
}


GameSession::~GameSession(void)
{
}
