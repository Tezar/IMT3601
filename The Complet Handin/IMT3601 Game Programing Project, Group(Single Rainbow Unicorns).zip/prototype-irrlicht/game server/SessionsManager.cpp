#include "StdAfx.h"
//#include "SessionsManager.hpp"
//
//
//SessionsManagerClass::SessionsManager(void)
//{
//}
//
//
//SessionsManagerClass::~SessionsManager(void)
//{
//}
